package Realtime.plot;


import anywheresoftware.b4a.B4AMenuItem;
import android.app.Activity;
import android.os.Bundle;
import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.B4AActivity;
import anywheresoftware.b4a.ObjectWrapper;
import anywheresoftware.b4a.objects.ActivityWrapper;
import java.lang.reflect.InvocationTargetException;
import anywheresoftware.b4a.B4AUncaughtException;
import anywheresoftware.b4a.debug.*;
import java.lang.ref.WeakReference;

public class main extends Activity implements B4AActivity{
	public static main mostCurrent;
	static boolean afterFirstLayout;
	static boolean isFirst = true;
    private static boolean processGlobalsRun = false;
	BALayout layout;
	public static BA processBA;
	BA activityBA;
    ActivityWrapper _activity;
    java.util.ArrayList<B4AMenuItem> menuItems;
	public static final boolean fullScreen = true;
	public static final boolean includeTitle = false;
    public static WeakReference<Activity> previousOne;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
        mostCurrent = this;
		if (processBA == null) {
			processBA = new BA(this.getApplicationContext(), null, null, "Realtime.plot", "Realtime.plot.main");
			processBA.loadHtSubs(this.getClass());
	        float deviceScale = getApplicationContext().getResources().getDisplayMetrics().density;
	        BALayout.setDeviceScale(deviceScale);
            
		}
		else if (previousOne != null) {
			Activity p = previousOne.get();
			if (p != null && p != this) {
                BA.LogInfo("Killing previous instance (main).");
				p.finish();
			}
		}
        processBA.setActivityPaused(true);
        processBA.runHook("oncreate", this, null);
		if (!includeTitle) {
        	this.getWindow().requestFeature(android.view.Window.FEATURE_NO_TITLE);
        }
        if (fullScreen) {
        	getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,   
        			android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
		
        processBA.sharedProcessBA.activityBA = null;
		layout = new BALayout(this);
		setContentView(layout);
		afterFirstLayout = false;
        WaitForLayout wl = new WaitForLayout();
        if (anywheresoftware.b4a.objects.ServiceHelper.StarterHelper.startFromActivity(this, processBA, wl, true))
		    BA.handler.postDelayed(wl, 5);

	}
	static class WaitForLayout implements Runnable {
		public void run() {
			if (afterFirstLayout)
				return;
			if (mostCurrent == null)
				return;
            
			if (mostCurrent.layout.getWidth() == 0) {
				BA.handler.postDelayed(this, 5);
				return;
			}
			mostCurrent.layout.getLayoutParams().height = mostCurrent.layout.getHeight();
			mostCurrent.layout.getLayoutParams().width = mostCurrent.layout.getWidth();
			afterFirstLayout = true;
			mostCurrent.afterFirstLayout();
		}
	}
	private void afterFirstLayout() {
        if (this != mostCurrent)
			return;
		activityBA = new BA(this, layout, processBA, "Realtime.plot", "Realtime.plot.main");
        
        processBA.sharedProcessBA.activityBA = new java.lang.ref.WeakReference<BA>(activityBA);
        anywheresoftware.b4a.objects.ViewWrapper.lastId = 0;
        _activity = new ActivityWrapper(activityBA, "activity");
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (BA.isShellModeRuntimeCheck(processBA)) {
			if (isFirst)
				processBA.raiseEvent2(null, true, "SHELL", false);
			processBA.raiseEvent2(null, true, "CREATE", true, "Realtime.plot.main", processBA, activityBA, _activity, anywheresoftware.b4a.keywords.Common.Density, mostCurrent);
			_activity.reinitializeForShell(activityBA, "activity");
		}
        initializeProcessGlobals();		
        initializeGlobals();
        
        BA.LogInfo("** Activity (main) Create, isFirst = " + isFirst + " **");
        processBA.raiseEvent2(null, true, "activity_create", false, isFirst);
		isFirst = false;
		if (this != mostCurrent)
			return;
        processBA.setActivityPaused(false);
        BA.LogInfo("** Activity (main) Resume **");
        processBA.raiseEvent(null, "activity_resume");
        if (android.os.Build.VERSION.SDK_INT >= 11) {
			try {
				android.app.Activity.class.getMethod("invalidateOptionsMenu").invoke(this,(Object[]) null);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
	public void addMenuItem(B4AMenuItem item) {
		if (menuItems == null)
			menuItems = new java.util.ArrayList<B4AMenuItem>();
		menuItems.add(item);
	}
	@Override
	public boolean onCreateOptionsMenu(android.view.Menu menu) {
		super.onCreateOptionsMenu(menu);
        try {
            if (processBA.subExists("activity_actionbarhomeclick")) {
                Class.forName("android.app.ActionBar").getMethod("setHomeButtonEnabled", boolean.class).invoke(
                    getClass().getMethod("getActionBar").invoke(this), true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (processBA.runHook("oncreateoptionsmenu", this, new Object[] {menu}))
            return true;
		if (menuItems == null)
			return false;
		for (B4AMenuItem bmi : menuItems) {
			android.view.MenuItem mi = menu.add(bmi.title);
			if (bmi.drawable != null)
				mi.setIcon(bmi.drawable);
            if (android.os.Build.VERSION.SDK_INT >= 11) {
				try {
                    if (bmi.addToBar) {
				        android.view.MenuItem.class.getMethod("setShowAsAction", int.class).invoke(mi, 1);
                    }
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			mi.setOnMenuItemClickListener(new B4AMenuItemsClickListener(bmi.eventName.toLowerCase(BA.cul)));
		}
        
		return true;
	}   
 @Override
 public boolean onOptionsItemSelected(android.view.MenuItem item) {
    if (item.getItemId() == 16908332) {
        processBA.raiseEvent(null, "activity_actionbarhomeclick");
        return true;
    }
    else
        return super.onOptionsItemSelected(item); 
}
@Override
 public boolean onPrepareOptionsMenu(android.view.Menu menu) {
    super.onPrepareOptionsMenu(menu);
    processBA.runHook("onprepareoptionsmenu", this, new Object[] {menu});
    return true;
    
 }
 protected void onStart() {
    super.onStart();
    processBA.runHook("onstart", this, null);
}
 protected void onStop() {
    super.onStop();
    processBA.runHook("onstop", this, null);
}
    public void onWindowFocusChanged(boolean hasFocus) {
       super.onWindowFocusChanged(hasFocus);
       if (processBA.subExists("activity_windowfocuschanged"))
           processBA.raiseEvent2(null, true, "activity_windowfocuschanged", false, hasFocus);
    }
	private class B4AMenuItemsClickListener implements android.view.MenuItem.OnMenuItemClickListener {
		private final String eventName;
		public B4AMenuItemsClickListener(String eventName) {
			this.eventName = eventName;
		}
		public boolean onMenuItemClick(android.view.MenuItem item) {
			processBA.raiseEventFromUI(item.getTitle(), eventName + "_click");
			return true;
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}
    private Boolean onKeySubExist = null;
    private Boolean onKeyUpSubExist = null;
	@Override
	public boolean onKeyDown(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeydown", this, new Object[] {keyCode, event}))
            return true;
		if (onKeySubExist == null)
			onKeySubExist = processBA.subExists("activity_keypress");
		if (onKeySubExist) {
			if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK &&
					android.os.Build.VERSION.SDK_INT >= 18) {
				HandleKeyDelayed hk = new HandleKeyDelayed();
				hk.kc = keyCode;
				BA.handler.post(hk);
				return true;
			}
			else {
				boolean res = new HandleKeyDelayed().runDirectly(keyCode);
				if (res)
					return true;
			}
		}
		return super.onKeyDown(keyCode, event);
	}
	private class HandleKeyDelayed implements Runnable {
		int kc;
		public void run() {
			runDirectly(kc);
		}
		public boolean runDirectly(int keyCode) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keypress", false, keyCode);
			if (res == null || res == true) {
                return true;
            }
            else if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK) {
				finish();
				return true;
			}
            return false;
		}
		
	}
    @Override
	public boolean onKeyUp(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeyup", this, new Object[] {keyCode, event}))
            return true;
		if (onKeyUpSubExist == null)
			onKeyUpSubExist = processBA.subExists("activity_keyup");
		if (onKeyUpSubExist) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keyup", false, keyCode);
			if (res == null || res == true)
				return true;
		}
		return super.onKeyUp(keyCode, event);
	}
	@Override
	public void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
		this.setIntent(intent);
        processBA.runHook("onnewintent", this, new Object[] {intent});
	}
    @Override 
	public void onPause() {
		super.onPause();
        if (_activity == null)
            return;
        if (this != mostCurrent)
			return;
		anywheresoftware.b4a.Msgbox.dismiss(true);
        BA.LogInfo("** Activity (main) Pause, UserClosed = " + activityBA.activity.isFinishing() + " **");
        if (mostCurrent != null)
            processBA.raiseEvent2(_activity, true, "activity_pause", false, activityBA.activity.isFinishing());		
        processBA.setActivityPaused(true);
        mostCurrent = null;
        if (!activityBA.activity.isFinishing())
			previousOne = new WeakReference<Activity>(this);
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        processBA.runHook("onpause", this, null);
	}

	@Override
	public void onDestroy() {
        super.onDestroy();
		previousOne = null;
        processBA.runHook("ondestroy", this, null);
	}
    @Override 
	public void onResume() {
		super.onResume();
        mostCurrent = this;
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (activityBA != null) { //will be null during activity create (which waits for AfterLayout).
        	ResumeMessage rm = new ResumeMessage(mostCurrent);
        	BA.handler.post(rm);
        }
        processBA.runHook("onresume", this, null);
	}
    private static class ResumeMessage implements Runnable {
    	private final WeakReference<Activity> activity;
    	public ResumeMessage(Activity activity) {
    		this.activity = new WeakReference<Activity>(activity);
    	}
		public void run() {
            main mc = mostCurrent;
			if (mc == null || mc != activity.get())
				return;
			processBA.setActivityPaused(false);
            BA.LogInfo("** Activity (main) Resume **");
            if (mc != mostCurrent)
                return;
		    processBA.raiseEvent(mc._activity, "activity_resume", (Object[])null);
		}
    }
	@Override
	protected void onActivityResult(int requestCode, int resultCode,
	      android.content.Intent data) {
		processBA.onActivityResult(requestCode, resultCode, data);
        processBA.runHook("onactivityresult", this, new Object[] {requestCode, resultCode});
	}
	private static void initializeGlobals() {
		processBA.raiseEvent2(null, true, "globals", false, (Object[])null);
	}
    public void onRequestPermissionsResult(int requestCode,
        String permissions[], int[] grantResults) {
        for (int i = 0;i < permissions.length;i++) {
            Object[] o = new Object[] {permissions[i], grantResults[i] == 0};
            processBA.raiseEventFromDifferentThread(null,null, 0, "activity_permissionresult", true, o);
        }
            
    }

public anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4a.objects.Timer _timer1 = null;
public static anywheresoftware.b4a.objects.SocketWrapper.UDPSocket _udps = null;
public static anywheresoftware.b4a.objects.SocketWrapper.UDPSocket.UDPPacket _udpp = null;
public static anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper _server = null;
public static String _shrip = "";
public static String _shrport = "";
public static float _val = 0f;
public static float[] _valbuf = null;
public static byte _ss = (byte)0;
public static byte _mm = (byte)0;
public static String _tm = "";
public static String[] _tmbuf = null;
public anywheresoftware.b4a.objects.PanelWrapper _panelchart = null;
public anywheresoftware.b4a.objects.LabelWrapper _labelvalue = null;
public anywheresoftware.b4a.objects.ButtonWrapper _buttonstart = null;
public anywheresoftware.b4a.objects.ButtonWrapper _buttonstop = null;
public anywheresoftware.b4a.objects.ButtonWrapper _buttonreset = null;
public anywheresoftware.b4a.objects.drawable.BitmapDrawable _imgtogglebutton = null;
public anywheresoftware.b4a.objects.CompoundButtonWrapper.ToggleButtonWrapper _togglebuttona1 = null;
public anywheresoftware.b4a.objects.CompoundButtonWrapper.ToggleButtonWrapper _togglebuttona2 = null;
public anywheresoftware.b4a.objects.CompoundButtonWrapper.ToggleButtonWrapper _togglebuttona3 = null;
public anywheresoftware.b4a.objects.EditTextWrapper _edittextdestinationip1 = null;
public static String _value = "";
public anywheresoftware.b4a.objects.ButtonWrapper _buttonsend = null;
public anywheresoftware.b4a.objects.EditTextWrapper _edittextdestinationip2 = null;
public anywheresoftware.b4a.objects.EditTextWrapper _edittextkp = null;
public anywheresoftware.b4a.objects.EditTextWrapper _edittextki = null;
public anywheresoftware.b4a.objects.EditTextWrapper _edittextkd = null;
public static String _pid = "";
public Realtime.plot.charts _charts = null;

public static boolean isAnyActivityVisible() {
    boolean vis = false;
vis = vis | (main.mostCurrent != null);
return vis;}
public static String  _activity_create(boolean _firsttime) throws Exception{
anywheresoftware.b4a.objects.drawable.ColorDrawable _cd = null;
 //BA.debugLineNum = 54;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
 //BA.debugLineNum = 55;BA.debugLine="Activity.LoadLayout(\"1\")";
mostCurrent._activity.LoadLayout("1",mostCurrent.activityBA);
 //BA.debugLineNum = 57;BA.debugLine="Timer1.Initialize(\"Timer1\",1000)";
_timer1.Initialize(processBA,"Timer1",(long) (1000));
 //BA.debugLineNum = 58;BA.debugLine="DateTime.DateFormat = \"HH:mm:ss\"";
anywheresoftware.b4a.keywords.Common.DateTime.setDateFormat("HH:mm:ss");
 //BA.debugLineNum = 60;BA.debugLine="ButtonReset.Enabled = True";
mostCurrent._buttonreset.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 61;BA.debugLine="ButtonStart.Enabled = True";
mostCurrent._buttonstart.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 63;BA.debugLine="Reset_Graph";
_reset_graph();
 //BA.debugLineNum = 65;BA.debugLine="Private cd As ColorDrawable";
_cd = new anywheresoftware.b4a.objects.drawable.ColorDrawable();
 //BA.debugLineNum = 66;BA.debugLine="cd.Initialize(Colors.Transparent, 0)";
_cd.Initialize(anywheresoftware.b4a.keywords.Common.Colors.Transparent,(int) (0));
 //BA.debugLineNum = 67;BA.debugLine="EditTextDestinationIP1.Background = cd";
mostCurrent._edittextdestinationip1.setBackground((android.graphics.drawable.Drawable)(_cd.getObject()));
 //BA.debugLineNum = 68;BA.debugLine="If FirstTime Then";
if (_firsttime) { 
 //BA.debugLineNum = 69;BA.debugLine="UdpS.Initialize(\"UdpSEvent\", 2000, 1024)";
_udps.Initialize(processBA,"UdpSEvent",(int) (2000),(int) (1024));
 };
 //BA.debugLineNum = 71;BA.debugLine="EditTextDestinationIP1.Text = ShrIP";
mostCurrent._edittextdestinationip1.setText(BA.ObjectToCharSequence(_shrip));
 //BA.debugLineNum = 74;BA.debugLine="ImgToggleButton.Initialize(LoadBitmap(File.DirAss";
mostCurrent._imgtogglebutton.Initialize((android.graphics.Bitmap)(anywheresoftware.b4a.keywords.Common.LoadBitmap(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"Toggle off.png").getObject()));
 //BA.debugLineNum = 75;BA.debugLine="ImgToggleButton.Gravity = Gravity.FILL";
mostCurrent._imgtogglebutton.setGravity(anywheresoftware.b4a.keywords.Common.Gravity.FILL);
 //BA.debugLineNum = 76;BA.debugLine="ToggleButtonA1.Background = ImgToggleButton";
mostCurrent._togglebuttona1.setBackground((android.graphics.drawable.Drawable)(mostCurrent._imgtogglebutton.getObject()));
 //BA.debugLineNum = 77;BA.debugLine="ToggleButtonA2.Background = ImgToggleButton";
mostCurrent._togglebuttona2.setBackground((android.graphics.drawable.Drawable)(mostCurrent._imgtogglebutton.getObject()));
 //BA.debugLineNum = 78;BA.debugLine="ToggleButtonA3.Background = ImgToggleButton";
mostCurrent._togglebuttona3.setBackground((android.graphics.drawable.Drawable)(mostCurrent._imgtogglebutton.getObject()));
 //BA.debugLineNum = 80;BA.debugLine="End Sub";
return "";
}
public static String  _activity_pause(boolean _userclosed) throws Exception{
 //BA.debugLineNum = 156;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
 //BA.debugLineNum = 158;BA.debugLine="End Sub";
return "";
}
public static String  _activity_resume() throws Exception{
 //BA.debugLineNum = 152;BA.debugLine="Sub Activity_Resume";
 //BA.debugLineNum = 154;BA.debugLine="End Sub";
return "";
}
public static String  _buttonreset_click() throws Exception{
 //BA.debugLineNum = 177;BA.debugLine="Sub ButtonReset_Click";
 //BA.debugLineNum = 178;BA.debugLine="Reset_Graph";
_reset_graph();
 //BA.debugLineNum = 179;BA.debugLine="End Sub";
return "";
}
public static String  _buttonsend_click() throws Exception{
 //BA.debugLineNum = 280;BA.debugLine="Sub ButtonSend_Click";
 //BA.debugLineNum = 281;BA.debugLine="If EditTextDestinationIP2.Text = \"\" Or EditTextKp";
if ((mostCurrent._edittextdestinationip2.getText()).equals("") || (mostCurrent._edittextkp.getText()).equals("") || (mostCurrent._edittextki.getText()).equals("") || (mostCurrent._edittextkd.getText()).equals("")) { 
 //BA.debugLineNum = 282;BA.debugLine="ToastMessageShow(\"Destination IP,Kp,Ki and Kd ca";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("Destination IP,Kp,Ki and Kd cannot be empty !!!"),anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 283;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 285;BA.debugLine="PID = EditTextKp.Text & \"S\" & EditTextKi.Text & \"";
mostCurrent._pid = mostCurrent._edittextkp.getText()+"S"+mostCurrent._edittextki.getText()+"S"+mostCurrent._edittextkd.getText();
 //BA.debugLineNum = 286;BA.debugLine="UdpP.Initialize(PID.GetBytes(\"ASCII\"), EditTextDe";
_udpp.Initialize(mostCurrent._pid.getBytes("ASCII"),mostCurrent._edittextdestinationip2.getText(),(int) (4210));
 //BA.debugLineNum = 287;BA.debugLine="UdpS.Send(UdpP)";
_udps.Send(_udpp);
 //BA.debugLineNum = 288;BA.debugLine="ToastMessageShow(\"Sending PID.\",False)";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("Sending PID."),anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 289;BA.debugLine="End Sub";
return "";
}
public static String  _buttonstart_click() throws Exception{
 //BA.debugLineNum = 163;BA.debugLine="Sub ButtonStart_Click";
 //BA.debugLineNum = 164;BA.debugLine="Timer1.Enabled = True";
_timer1.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 165;BA.debugLine="ButtonStart.Enabled = False";
mostCurrent._buttonstart.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 166;BA.debugLine="ButtonReset.Enabled = False";
mostCurrent._buttonreset.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 167;BA.debugLine="ButtonStop.Enabled = True";
mostCurrent._buttonstop.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 168;BA.debugLine="End Sub";
return "";
}
public static String  _buttonstop_click() throws Exception{
 //BA.debugLineNum = 170;BA.debugLine="Sub ButtonStop_Click";
 //BA.debugLineNum = 171;BA.debugLine="Timer1.Enabled = False";
_timer1.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 172;BA.debugLine="ButtonStop.Enabled = False";
mostCurrent._buttonstop.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 173;BA.debugLine="ButtonStart.Enabled = True";
mostCurrent._buttonstart.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 174;BA.debugLine="ButtonReset.Enabled = True";
mostCurrent._buttonreset.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 175;BA.debugLine="End Sub";
return "";
}
public static String  _globals() throws Exception{
 //BA.debugLineNum = 26;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 28;BA.debugLine="Dim Val As Float";
_val = 0f;
 //BA.debugLineNum = 29;BA.debugLine="Dim ValBuf(12) As Float";
_valbuf = new float[(int) (12)];
;
 //BA.debugLineNum = 30;BA.debugLine="Dim ss, mm As Byte";
_ss = (byte)0;
_mm = (byte)0;
 //BA.debugLineNum = 31;BA.debugLine="Dim tm, tmbuf(12) As String";
mostCurrent._tm = "";
mostCurrent._tmbuf = new String[(int) (12)];
java.util.Arrays.fill(mostCurrent._tmbuf,"");
 //BA.debugLineNum = 32;BA.debugLine="Private PanelChart As Panel";
mostCurrent._panelchart = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 33;BA.debugLine="Private LabelValue As Label";
mostCurrent._labelvalue = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 34;BA.debugLine="Private ButtonStart As Button";
mostCurrent._buttonstart = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 35;BA.debugLine="Private ButtonStop As Button";
mostCurrent._buttonstop = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 36;BA.debugLine="Private ButtonReset As Button";
mostCurrent._buttonreset = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 39;BA.debugLine="Dim ImgToggleButton As BitmapDrawable";
mostCurrent._imgtogglebutton = new anywheresoftware.b4a.objects.drawable.BitmapDrawable();
 //BA.debugLineNum = 40;BA.debugLine="Private ToggleButtonA1 As ToggleButton";
mostCurrent._togglebuttona1 = new anywheresoftware.b4a.objects.CompoundButtonWrapper.ToggleButtonWrapper();
 //BA.debugLineNum = 41;BA.debugLine="Private ToggleButtonA2 As ToggleButton";
mostCurrent._togglebuttona2 = new anywheresoftware.b4a.objects.CompoundButtonWrapper.ToggleButtonWrapper();
 //BA.debugLineNum = 42;BA.debugLine="Private ToggleButtonA3 As ToggleButton";
mostCurrent._togglebuttona3 = new anywheresoftware.b4a.objects.CompoundButtonWrapper.ToggleButtonWrapper();
 //BA.debugLineNum = 43;BA.debugLine="Private EditTextDestinationIP1 As EditText";
mostCurrent._edittextdestinationip1 = new anywheresoftware.b4a.objects.EditTextWrapper();
 //BA.debugLineNum = 44;BA.debugLine="Public Value As String";
mostCurrent._value = "";
 //BA.debugLineNum = 46;BA.debugLine="Private ButtonSend As Button";
mostCurrent._buttonsend = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 47;BA.debugLine="Private EditTextDestinationIP2 As EditText";
mostCurrent._edittextdestinationip2 = new anywheresoftware.b4a.objects.EditTextWrapper();
 //BA.debugLineNum = 48;BA.debugLine="Private EditTextKp As EditText";
mostCurrent._edittextkp = new anywheresoftware.b4a.objects.EditTextWrapper();
 //BA.debugLineNum = 49;BA.debugLine="Private EditTextKi As EditText";
mostCurrent._edittextki = new anywheresoftware.b4a.objects.EditTextWrapper();
 //BA.debugLineNum = 50;BA.debugLine="Private EditTextKd As EditText";
mostCurrent._edittextkd = new anywheresoftware.b4a.objects.EditTextWrapper();
 //BA.debugLineNum = 51;BA.debugLine="Public PID As String";
mostCurrent._pid = "";
 //BA.debugLineNum = 52;BA.debugLine="End Sub";
return "";
}
public static String  _graphdraw() throws Exception{
Realtime.plot.charts._linedata _ld = null;
Realtime.plot.charts._graph _g = null;
 //BA.debugLineNum = 83;BA.debugLine="Sub graphdraw";
 //BA.debugLineNum = 84;BA.debugLine="Dim LD As LineData";
_ld = new Realtime.plot.charts._linedata();
 //BA.debugLineNum = 85;BA.debugLine="LD.Initialize";
_ld.Initialize();
 //BA.debugLineNum = 86;BA.debugLine="LD.Target = PanelChart";
_ld.Target /*anywheresoftware.b4a.objects.PanelWrapper*/  = mostCurrent._panelchart;
 //BA.debugLineNum = 87;BA.debugLine="Charts.AddLineColor(LD, Colors.Red)";
mostCurrent._charts._addlinecolor /*String*/ (mostCurrent.activityBA,_ld,anywheresoftware.b4a.keywords.Common.Colors.Red);
 //BA.debugLineNum = 89;BA.debugLine="Charts.AddLinePoint(LD, tmbuf(0), ValBuf(0), True";
mostCurrent._charts._addlinepoint /*String*/ (mostCurrent.activityBA,_ld,mostCurrent._tmbuf[(int) (0)],_valbuf[(int) (0)],anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 90;BA.debugLine="Charts.AddLinePoint(LD, tmbuf(1), ValBuf(1), True";
mostCurrent._charts._addlinepoint /*String*/ (mostCurrent.activityBA,_ld,mostCurrent._tmbuf[(int) (1)],_valbuf[(int) (1)],anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 91;BA.debugLine="Charts.AddLinePoint(LD, tmbuf(2), ValBuf(2), True";
mostCurrent._charts._addlinepoint /*String*/ (mostCurrent.activityBA,_ld,mostCurrent._tmbuf[(int) (2)],_valbuf[(int) (2)],anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 92;BA.debugLine="Charts.AddLinePoint(LD, tmbuf(3), ValBuf(3), True";
mostCurrent._charts._addlinepoint /*String*/ (mostCurrent.activityBA,_ld,mostCurrent._tmbuf[(int) (3)],_valbuf[(int) (3)],anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 93;BA.debugLine="Charts.AddLinePoint(LD, tmbuf(4), ValBuf(4), True";
mostCurrent._charts._addlinepoint /*String*/ (mostCurrent.activityBA,_ld,mostCurrent._tmbuf[(int) (4)],_valbuf[(int) (4)],anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 94;BA.debugLine="Charts.AddLinePoint(LD, tmbuf(5), ValBuf(5), True";
mostCurrent._charts._addlinepoint /*String*/ (mostCurrent.activityBA,_ld,mostCurrent._tmbuf[(int) (5)],_valbuf[(int) (5)],anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 95;BA.debugLine="Charts.AddLinePoint(LD, tmbuf(6), ValBuf(6), True";
mostCurrent._charts._addlinepoint /*String*/ (mostCurrent.activityBA,_ld,mostCurrent._tmbuf[(int) (6)],_valbuf[(int) (6)],anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 96;BA.debugLine="Charts.AddLinePoint(LD, tmbuf(7), ValBuf(7), True";
mostCurrent._charts._addlinepoint /*String*/ (mostCurrent.activityBA,_ld,mostCurrent._tmbuf[(int) (7)],_valbuf[(int) (7)],anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 97;BA.debugLine="Charts.AddLinePoint(LD, tmbuf(8), ValBuf(8), True";
mostCurrent._charts._addlinepoint /*String*/ (mostCurrent.activityBA,_ld,mostCurrent._tmbuf[(int) (8)],_valbuf[(int) (8)],anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 98;BA.debugLine="Charts.AddLinePoint(LD, tmbuf(9), ValBuf(9), True";
mostCurrent._charts._addlinepoint /*String*/ (mostCurrent.activityBA,_ld,mostCurrent._tmbuf[(int) (9)],_valbuf[(int) (9)],anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 99;BA.debugLine="Charts.AddLinePoint(LD, tmbuf(10), ValBuf(10), Tr";
mostCurrent._charts._addlinepoint /*String*/ (mostCurrent.activityBA,_ld,mostCurrent._tmbuf[(int) (10)],_valbuf[(int) (10)],anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 100;BA.debugLine="Charts.AddLinePoint(LD, tmbuf(11), ValBuf(11), Tr";
mostCurrent._charts._addlinepoint /*String*/ (mostCurrent.activityBA,_ld,mostCurrent._tmbuf[(int) (11)],_valbuf[(int) (11)],anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 103;BA.debugLine="Dim G As Graph";
_g = new Realtime.plot.charts._graph();
 //BA.debugLineNum = 104;BA.debugLine="G.Initialize";
_g.Initialize();
 //BA.debugLineNum = 105;BA.debugLine="G.Title = \"Sensor Value :\" & Value";
_g.Title /*String*/  = "Sensor Value :"+mostCurrent._value;
 //BA.debugLineNum = 107;BA.debugLine="G.XAxis = \"Time (Minute & Second)\"";
_g.XAxis /*String*/  = "Time (Minute & Second)";
 //BA.debugLineNum = 108;BA.debugLine="G.YAxis = \"Value\"";
_g.YAxis /*String*/  = "Value";
 //BA.debugLineNum = 109;BA.debugLine="G.YStart = 0";
_g.YStart /*float*/  = (float) (0);
 //BA.debugLineNum = 110;BA.debugLine="G.YEnd = 200";
_g.YEnd /*float*/  = (float) (200);
 //BA.debugLineNum = 112;BA.debugLine="G.YInterval = 20";
_g.YInterval /*float*/  = (float) (20);
 //BA.debugLineNum = 113;BA.debugLine="G.AxisColor = Colors.Black";
_g.AxisColor /*int*/  = anywheresoftware.b4a.keywords.Common.Colors.Black;
 //BA.debugLineNum = 114;BA.debugLine="Charts.DrawLineChart(G, LD, Colors.White)";
mostCurrent._charts._drawlinechart /*String*/ (mostCurrent.activityBA,_g,_ld,anywheresoftware.b4a.keywords.Common.Colors.White);
 //BA.debugLineNum = 115;BA.debugLine="End Sub";
return "";
}

public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
charts._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 17;BA.debugLine="Private Timer1 As Timer";
_timer1 = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 20;BA.debugLine="Public UdpS As UDPSocket";
_udps = new anywheresoftware.b4a.objects.SocketWrapper.UDPSocket();
 //BA.debugLineNum = 21;BA.debugLine="Public UdpP As UDPPacket";
_udpp = new anywheresoftware.b4a.objects.SocketWrapper.UDPSocket.UDPPacket();
 //BA.debugLineNum = 22;BA.debugLine="Private server As ServerSocket";
_server = new anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper();
 //BA.debugLineNum = 23;BA.debugLine="Public ShrIP, ShrPort As String";
_shrip = "";
_shrport = "";
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return "";
}
public static String  _reset_graph() throws Exception{
 //BA.debugLineNum = 181;BA.debugLine="Sub Reset_Graph";
 //BA.debugLineNum = 182;BA.debugLine="ValBuf(0) = 0";
_valbuf[(int) (0)] = (float) (0);
 //BA.debugLineNum = 183;BA.debugLine="ValBuf(1) = 0";
_valbuf[(int) (1)] = (float) (0);
 //BA.debugLineNum = 184;BA.debugLine="ValBuf(2) = 0";
_valbuf[(int) (2)] = (float) (0);
 //BA.debugLineNum = 185;BA.debugLine="ValBuf(3) = 0";
_valbuf[(int) (3)] = (float) (0);
 //BA.debugLineNum = 186;BA.debugLine="ValBuf(4) = 0";
_valbuf[(int) (4)] = (float) (0);
 //BA.debugLineNum = 187;BA.debugLine="ValBuf(5) = 0";
_valbuf[(int) (5)] = (float) (0);
 //BA.debugLineNum = 188;BA.debugLine="ValBuf(6) = 0";
_valbuf[(int) (6)] = (float) (0);
 //BA.debugLineNum = 189;BA.debugLine="ValBuf(7) = 0";
_valbuf[(int) (7)] = (float) (0);
 //BA.debugLineNum = 190;BA.debugLine="ValBuf(8) = 0";
_valbuf[(int) (8)] = (float) (0);
 //BA.debugLineNum = 191;BA.debugLine="ValBuf(9) = 0";
_valbuf[(int) (9)] = (float) (0);
 //BA.debugLineNum = 192;BA.debugLine="ValBuf(10) = 0";
_valbuf[(int) (10)] = (float) (0);
 //BA.debugLineNum = 193;BA.debugLine="ValBuf(11) = 0";
_valbuf[(int) (11)] = (float) (0);
 //BA.debugLineNum = 194;BA.debugLine="graphdraw";
_graphdraw();
 //BA.debugLineNum = 195;BA.debugLine="End Sub";
return "";
}
public static String  _timer1_tick() throws Exception{
 //BA.debugLineNum = 117;BA.debugLine="Sub TImer1_Tick";
 //BA.debugLineNum = 118;BA.debugLine="Val = Value 'Rnd(0,200)";
_val = (float)(Double.parseDouble(mostCurrent._value));
 //BA.debugLineNum = 120;BA.debugLine="ValBuf(0) = ValBuf(1)";
_valbuf[(int) (0)] = _valbuf[(int) (1)];
 //BA.debugLineNum = 121;BA.debugLine="ValBuf(1) = ValBuf(2)";
_valbuf[(int) (1)] = _valbuf[(int) (2)];
 //BA.debugLineNum = 122;BA.debugLine="ValBuf(2) = ValBuf(3)";
_valbuf[(int) (2)] = _valbuf[(int) (3)];
 //BA.debugLineNum = 123;BA.debugLine="ValBuf(3) = ValBuf(4)";
_valbuf[(int) (3)] = _valbuf[(int) (4)];
 //BA.debugLineNum = 124;BA.debugLine="ValBuf(4) = ValBuf(5)";
_valbuf[(int) (4)] = _valbuf[(int) (5)];
 //BA.debugLineNum = 125;BA.debugLine="ValBuf(5) = ValBuf(6)";
_valbuf[(int) (5)] = _valbuf[(int) (6)];
 //BA.debugLineNum = 126;BA.debugLine="ValBuf(6) = ValBuf(7)";
_valbuf[(int) (6)] = _valbuf[(int) (7)];
 //BA.debugLineNum = 127;BA.debugLine="ValBuf(7) = ValBuf(8)";
_valbuf[(int) (7)] = _valbuf[(int) (8)];
 //BA.debugLineNum = 128;BA.debugLine="ValBuf(8) = ValBuf(9)";
_valbuf[(int) (8)] = _valbuf[(int) (9)];
 //BA.debugLineNum = 129;BA.debugLine="ValBuf(9) = ValBuf(10)";
_valbuf[(int) (9)] = _valbuf[(int) (10)];
 //BA.debugLineNum = 130;BA.debugLine="ValBuf(10) = ValBuf(11)";
_valbuf[(int) (10)] = _valbuf[(int) (11)];
 //BA.debugLineNum = 131;BA.debugLine="ValBuf(11) = Val";
_valbuf[(int) (11)] = _val;
 //BA.debugLineNum = 132;BA.debugLine="ss = DateTime.GetSecond(DateTime.Now)";
_ss = (byte) (anywheresoftware.b4a.keywords.Common.DateTime.GetSecond(anywheresoftware.b4a.keywords.Common.DateTime.getNow()));
 //BA.debugLineNum = 133;BA.debugLine="mm = DateTime.GetMinute(DateTime.Now)";
_mm = (byte) (anywheresoftware.b4a.keywords.Common.DateTime.GetMinute(anywheresoftware.b4a.keywords.Common.DateTime.getNow()));
 //BA.debugLineNum = 134;BA.debugLine="tm = mm & \":\" & ss";
mostCurrent._tm = BA.NumberToString(_mm)+":"+BA.NumberToString(_ss);
 //BA.debugLineNum = 136;BA.debugLine="tmbuf(0) = tmbuf(1)";
mostCurrent._tmbuf[(int) (0)] = mostCurrent._tmbuf[(int) (1)];
 //BA.debugLineNum = 137;BA.debugLine="tmbuf(1) = tmbuf(2)";
mostCurrent._tmbuf[(int) (1)] = mostCurrent._tmbuf[(int) (2)];
 //BA.debugLineNum = 138;BA.debugLine="tmbuf(2) = tmbuf(3)";
mostCurrent._tmbuf[(int) (2)] = mostCurrent._tmbuf[(int) (3)];
 //BA.debugLineNum = 139;BA.debugLine="tmbuf(3) = tmbuf(4)";
mostCurrent._tmbuf[(int) (3)] = mostCurrent._tmbuf[(int) (4)];
 //BA.debugLineNum = 140;BA.debugLine="tmbuf(4) = tmbuf(5)";
mostCurrent._tmbuf[(int) (4)] = mostCurrent._tmbuf[(int) (5)];
 //BA.debugLineNum = 141;BA.debugLine="tmbuf(5) = tmbuf(6)";
mostCurrent._tmbuf[(int) (5)] = mostCurrent._tmbuf[(int) (6)];
 //BA.debugLineNum = 142;BA.debugLine="tmbuf(6) = tmbuf(7)";
mostCurrent._tmbuf[(int) (6)] = mostCurrent._tmbuf[(int) (7)];
 //BA.debugLineNum = 143;BA.debugLine="tmbuf(7) = tmbuf(8)";
mostCurrent._tmbuf[(int) (7)] = mostCurrent._tmbuf[(int) (8)];
 //BA.debugLineNum = 144;BA.debugLine="tmbuf(8) = tmbuf(9)";
mostCurrent._tmbuf[(int) (8)] = mostCurrent._tmbuf[(int) (9)];
 //BA.debugLineNum = 145;BA.debugLine="tmbuf(9) = tmbuf(10)";
mostCurrent._tmbuf[(int) (9)] = mostCurrent._tmbuf[(int) (10)];
 //BA.debugLineNum = 146;BA.debugLine="tmbuf(10) = tmbuf(11)";
mostCurrent._tmbuf[(int) (10)] = mostCurrent._tmbuf[(int) (11)];
 //BA.debugLineNum = 147;BA.debugLine="tmbuf(11) = tm";
mostCurrent._tmbuf[(int) (11)] = mostCurrent._tm;
 //BA.debugLineNum = 149;BA.debugLine="graphdraw";
_graphdraw();
 //BA.debugLineNum = 150;BA.debugLine="End Sub";
return "";
}
public static String  _togglebuttona1_checkedchange(boolean _checked) throws Exception{
 //BA.debugLineNum = 197;BA.debugLine="Sub ToggleButtonA1_CheckedChange(Checked As Boolea";
 //BA.debugLineNum = 198;BA.debugLine="If EditTextDestinationIP1.Text = \"\" Then";
if ((mostCurrent._edittextdestinationip1.getText()).equals("")) { 
 //BA.debugLineNum = 199;BA.debugLine="ToastMessageShow(\"Destination IP and Destination";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("Destination IP and Destination Port cannot be empty !!!"),anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 200;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 204;BA.debugLine="If Checked = False Then";
if (_checked==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 205;BA.debugLine="ImgToggleButton.Initialize(LoadBitmap(File.DirAs";
mostCurrent._imgtogglebutton.Initialize((android.graphics.Bitmap)(anywheresoftware.b4a.keywords.Common.LoadBitmap(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"Toggle off.png").getObject()));
 //BA.debugLineNum = 206;BA.debugLine="ImgToggleButton.Gravity = Gravity.FILL";
mostCurrent._imgtogglebutton.setGravity(anywheresoftware.b4a.keywords.Common.Gravity.FILL);
 //BA.debugLineNum = 207;BA.debugLine="ToggleButtonA1.Background = ImgToggleButton";
mostCurrent._togglebuttona1.setBackground((android.graphics.drawable.Drawable)(mostCurrent._imgtogglebutton.getObject()));
 //BA.debugLineNum = 208;BA.debugLine="UdpP.Initialize(\"A1Off\".GetBytes(\"ASCII\"), EditT";
_udpp.Initialize("A1Off".getBytes("ASCII"),mostCurrent._edittextdestinationip1.getText(),(int) (4210));
 //BA.debugLineNum = 209;BA.debugLine="UdpS.Send(UdpP)";
_udps.Send(_udpp);
 //BA.debugLineNum = 211;BA.debugLine="ToastMessageShow(\"Node1:S1 Off\", False)";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("Node1:S1 Off"),anywheresoftware.b4a.keywords.Common.False);
 }else {
 //BA.debugLineNum = 213;BA.debugLine="ImgToggleButton.Initialize(LoadBitmap(File.DirAs";
mostCurrent._imgtogglebutton.Initialize((android.graphics.Bitmap)(anywheresoftware.b4a.keywords.Common.LoadBitmap(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"Toggle on.png").getObject()));
 //BA.debugLineNum = 214;BA.debugLine="ImgToggleButton.Gravity = Gravity.FILL";
mostCurrent._imgtogglebutton.setGravity(anywheresoftware.b4a.keywords.Common.Gravity.FILL);
 //BA.debugLineNum = 215;BA.debugLine="ToggleButtonA1.Background = ImgToggleButton";
mostCurrent._togglebuttona1.setBackground((android.graphics.drawable.Drawable)(mostCurrent._imgtogglebutton.getObject()));
 //BA.debugLineNum = 216;BA.debugLine="UdpP.Initialize(\"A1On\".GetBytes(\"ASCII\"), EditTe";
_udpp.Initialize("A1On".getBytes("ASCII"),mostCurrent._edittextdestinationip1.getText(),(int) (4210));
 //BA.debugLineNum = 217;BA.debugLine="UdpS.Send(UdpP)";
_udps.Send(_udpp);
 //BA.debugLineNum = 219;BA.debugLine="ToastMessageShow(\"Node2:S1 On\", False)";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("Node2:S1 On"),anywheresoftware.b4a.keywords.Common.False);
 };
 //BA.debugLineNum = 221;BA.debugLine="End Sub";
return "";
}
public static String  _togglebuttona2_checkedchange(boolean _checked) throws Exception{
 //BA.debugLineNum = 223;BA.debugLine="Sub ToggleButtonA2_CheckedChange(Checked As Boolea";
 //BA.debugLineNum = 224;BA.debugLine="If EditTextDestinationIP1.Text = \"\" Then";
if ((mostCurrent._edittextdestinationip1.getText()).equals("")) { 
 //BA.debugLineNum = 225;BA.debugLine="ToastMessageShow(\"Destination IP and Destination";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("Destination IP and Destination Port cannot be empty !!!"),anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 226;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 230;BA.debugLine="If Checked = False Then";
if (_checked==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 231;BA.debugLine="ImgToggleButton.Initialize(LoadBitmap(File.DirAs";
mostCurrent._imgtogglebutton.Initialize((android.graphics.Bitmap)(anywheresoftware.b4a.keywords.Common.LoadBitmap(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"Toggle off.png").getObject()));
 //BA.debugLineNum = 232;BA.debugLine="ImgToggleButton.Gravity = Gravity.FILL";
mostCurrent._imgtogglebutton.setGravity(anywheresoftware.b4a.keywords.Common.Gravity.FILL);
 //BA.debugLineNum = 233;BA.debugLine="ToggleButtonA2.Background = ImgToggleButton";
mostCurrent._togglebuttona2.setBackground((android.graphics.drawable.Drawable)(mostCurrent._imgtogglebutton.getObject()));
 //BA.debugLineNum = 234;BA.debugLine="UdpP.Initialize(\"A2Off\".GetBytes(\"ASCII\"), EditT";
_udpp.Initialize("A2Off".getBytes("ASCII"),mostCurrent._edittextdestinationip1.getText(),(int) (4210));
 //BA.debugLineNum = 235;BA.debugLine="UdpS.Send(UdpP)";
_udps.Send(_udpp);
 //BA.debugLineNum = 237;BA.debugLine="ToastMessageShow(\"Node1:S2 Off\", False)";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("Node1:S2 Off"),anywheresoftware.b4a.keywords.Common.False);
 }else {
 //BA.debugLineNum = 239;BA.debugLine="ImgToggleButton.Initialize(LoadBitmap(File.DirAs";
mostCurrent._imgtogglebutton.Initialize((android.graphics.Bitmap)(anywheresoftware.b4a.keywords.Common.LoadBitmap(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"Toggle on.png").getObject()));
 //BA.debugLineNum = 240;BA.debugLine="ImgToggleButton.Gravity = Gravity.FILL";
mostCurrent._imgtogglebutton.setGravity(anywheresoftware.b4a.keywords.Common.Gravity.FILL);
 //BA.debugLineNum = 241;BA.debugLine="ToggleButtonA2.Background = ImgToggleButton";
mostCurrent._togglebuttona2.setBackground((android.graphics.drawable.Drawable)(mostCurrent._imgtogglebutton.getObject()));
 //BA.debugLineNum = 242;BA.debugLine="UdpP.Initialize(\"A2On\".GetBytes(\"ASCII\"), EditTe";
_udpp.Initialize("A2On".getBytes("ASCII"),mostCurrent._edittextdestinationip1.getText(),(int) (4210));
 //BA.debugLineNum = 243;BA.debugLine="UdpS.Send(UdpP)";
_udps.Send(_udpp);
 //BA.debugLineNum = 245;BA.debugLine="ToastMessageShow(\"Node1:S2 On\", False)";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("Node1:S2 On"),anywheresoftware.b4a.keywords.Common.False);
 };
 //BA.debugLineNum = 247;BA.debugLine="End Sub";
return "";
}
public static String  _togglebuttona3_checkedchange(boolean _checked) throws Exception{
 //BA.debugLineNum = 249;BA.debugLine="Sub ToggleButtonA3_CheckedChange(Checked As Boolea";
 //BA.debugLineNum = 250;BA.debugLine="If EditTextDestinationIP1.Text = \"\" Then";
if ((mostCurrent._edittextdestinationip1.getText()).equals("")) { 
 //BA.debugLineNum = 251;BA.debugLine="ToastMessageShow(\"Destination IP cannot be empty";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("Destination IP cannot be empty !!!"),anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 252;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 256;BA.debugLine="If Checked = False Then";
if (_checked==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 257;BA.debugLine="ImgToggleButton.Initialize(LoadBitmap(File.DirAs";
mostCurrent._imgtogglebutton.Initialize((android.graphics.Bitmap)(anywheresoftware.b4a.keywords.Common.LoadBitmap(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"Toggle off.png").getObject()));
 //BA.debugLineNum = 258;BA.debugLine="ImgToggleButton.Gravity = Gravity.FILL";
mostCurrent._imgtogglebutton.setGravity(anywheresoftware.b4a.keywords.Common.Gravity.FILL);
 //BA.debugLineNum = 259;BA.debugLine="ToggleButtonA3.Background = ImgToggleButton";
mostCurrent._togglebuttona3.setBackground((android.graphics.drawable.Drawable)(mostCurrent._imgtogglebutton.getObject()));
 //BA.debugLineNum = 260;BA.debugLine="UdpP.Initialize(\"A3Off\".GetBytes(\"ASCII\"), EditT";
_udpp.Initialize("A3Off".getBytes("ASCII"),mostCurrent._edittextdestinationip1.getText(),(int) (4210));
 //BA.debugLineNum = 261;BA.debugLine="UdpS.Send(UdpP)";
_udps.Send(_udpp);
 //BA.debugLineNum = 263;BA.debugLine="ToastMessageShow(\"Node1:S3 Off\", False)";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("Node1:S3 Off"),anywheresoftware.b4a.keywords.Common.False);
 }else {
 //BA.debugLineNum = 265;BA.debugLine="ImgToggleButton.Initialize(LoadBitmap(File.DirAs";
mostCurrent._imgtogglebutton.Initialize((android.graphics.Bitmap)(anywheresoftware.b4a.keywords.Common.LoadBitmap(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"Toggle on.png").getObject()));
 //BA.debugLineNum = 266;BA.debugLine="ImgToggleButton.Gravity = Gravity.FILL";
mostCurrent._imgtogglebutton.setGravity(anywheresoftware.b4a.keywords.Common.Gravity.FILL);
 //BA.debugLineNum = 267;BA.debugLine="ToggleButtonA3.Background = ImgToggleButton";
mostCurrent._togglebuttona3.setBackground((android.graphics.drawable.Drawable)(mostCurrent._imgtogglebutton.getObject()));
 //BA.debugLineNum = 268;BA.debugLine="UdpP.Initialize(\"A3On\".GetBytes(\"ASCII\"), EditTe";
_udpp.Initialize("A3On".getBytes("ASCII"),mostCurrent._edittextdestinationip1.getText(),(int) (4210));
 //BA.debugLineNum = 269;BA.debugLine="UdpS.Send(UdpP)";
_udps.Send(_udpp);
 //BA.debugLineNum = 271;BA.debugLine="ToastMessageShow(\"Node1:S3 On\", False)";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("Node1:S3 On"),anywheresoftware.b4a.keywords.Common.False);
 };
 //BA.debugLineNum = 273;BA.debugLine="End Sub";
return "";
}
public static String  _udpsevent_packetarrived(anywheresoftware.b4a.objects.SocketWrapper.UDPSocket.UDPPacket _packet) throws Exception{
 //BA.debugLineNum = 275;BA.debugLine="Sub UdpSEvent_PacketArrived (Packet As UDPPacket)";
 //BA.debugLineNum = 276;BA.debugLine="Value = BytesToString(Packet.Data, Packet.Offset,";
mostCurrent._value = anywheresoftware.b4a.keywords.Common.BytesToString(_packet.getData(),_packet.getOffset(),_packet.getLength(),"ASCII");
 //BA.debugLineNum = 277;BA.debugLine="End Sub";
return "";
}
}
